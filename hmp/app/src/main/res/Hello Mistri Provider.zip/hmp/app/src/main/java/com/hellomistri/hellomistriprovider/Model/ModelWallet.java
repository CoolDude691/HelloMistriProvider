package com.hellomistri.hellomistriprovider.Model;



public class ModelWallet {
    private String id;
    private String pid;
    private String message;
    private String status;
    private String amt;
    private String adddate;

    public ModelWallet(String id, String pid, String message, String status, String amt, String adddate) {
        this.id = id;
        this.pid = pid;
        this.message = message;
        this.status = status;
        this.amt = amt;
        this.adddate = adddate;
    }

    public String getID() { return id; }
    public void setID(String value) { this.id = value; }

    public String getPID() { return pid; }
    public void setPID(String value) { this.pid = value; }

    public String getMessage() { return message; }
    public void setMessage(String value) { this.message = value; }

    public String getStatus() { return status; }
    public void setStatus(String value) { this.status = value; }

    public String getAmt() { return amt; }
    public void setAmt(String value) { this.amt = value; }

    public String getAdddate() { return adddate; }
    public void setAdddate(String value) { this.adddate = value; }
}

