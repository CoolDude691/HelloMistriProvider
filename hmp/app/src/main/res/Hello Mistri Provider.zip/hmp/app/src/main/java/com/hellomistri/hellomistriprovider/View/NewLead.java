package com.hellomistri.hellomistriprovider.View;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hellomistri.hellomistriprovider.Adapter.MyAdapter;
import com.hellomistri.hellomistriprovider.Fragments.Wallet;
import com.hellomistri.hellomistriprovider.Model.Leads;
import com.hellomistri.hellomistriprovider.Model.User;
import com.hellomistri.hellomistriprovider.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NewLead extends AppCompatActivity {

    TextView address1,date,time1,mor;

    List<Leads> leadsList = new ArrayList<>();
    RecyclerView recyclerView;
    MyAdapter adapter;
    LinearLayout nodata;
    LinearLayoutManager linearLayoutManager;
    ImageView back;
    TextView noDataFound;

    SharedPreferences shp;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_lead);
//        address1=findViewById(R.id.addressI);
        //date=findViewById(R.id.dateI);
      //  time1=findViewById(R.id.timeI);
        back=findViewById(R.id.backBtn2);
        noDataFound=findViewById(R.id.noDataFound);
        nodata=findViewById(R.id.nodata1);



        Leads object= (Leads) getIntent().getSerializableExtra("device_object");

        Bundle bundle=new Bundle();

        bundle.putSerializable("deviceObject",object);

        User object1= (User) getIntent().getSerializableExtra("device_object1");

        Bundle bundle1=new Bundle();


      /*  Intent intent= new Intent(NewLead.this, Wallet.class);
        bundle1.putSerializable("deviceObject1",object1);

        intent.putExtras(bundle1);
        startActivity(intent);*/

        CallApi();

        recyclerView=findViewById(R.id.recyclerView);
        getSupportActionBar().hide();
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

      recyclerView.setHasFixedSize(true);
        linearLayoutManager= new LinearLayoutManager(this);

        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
      adapter= new MyAdapter(leadsList, new MyAdapter.ItemClickListner() {
          @Override
          public void onItemClick(TextView textView, int pos) {
             textView.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View view) {
                     Intent intent = new Intent(NewLead.this,LeadDetaills.class);
                     intent.putExtra("device_object",leadsList.get(pos));
                    // intent.putExtra("device_object1",leadsList.get(pos));


                     startActivity(intent);

                 }
             });
          }

          @Override
          public void onItemSelection(View view, ConstraintLayout constraintLayout, int pos) {

          }
      });
      recyclerView.setAdapter(adapter);



    }

    private void CallApi() {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();


        shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();

/*
     String cid= String.valueOf(1);
*/


        String category_id = shp.getString("category_id", "");

        String url="https://hellomistri.in/Api/getUserpartnerServicedetails";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();



                Log.d("leads",response);

                try {


                    JSONArray leads= new JSONArray(response);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        showNotification();
                    }

                    for (int i=0;i<leads.length();i++)
                    {






                        JSONObject jsonObject= leads.getJSONObject(i);



                        String id = jsonObject.getString("id");
                        String customer_id = jsonObject.getString("customer_id");
                        String provider_id= jsonObject.getString("provider_id");
                        String c_atname = jsonObject.getString("c_atname");
                        String sub_cat_name = jsonObject.getString("sub_cat_name");
                        String service_name = jsonObject.getString("service_name");
                        String city_name = jsonObject.getString("city_name");
                        String message = jsonObject.getString("message");
                        String or_date = jsonObject.getString("or_date");
                        String o_status = jsonObject.getString("o_status");
                        String or_address = jsonObject.getString("or_address");


                        editor.putString("orderid",jsonObject.getString("id"));
                        editor.commit();
                        // String status = jsonObject.getString("status");

                    Leads leads1=new Leads(id,customer_id,provider_id,c_atname,sub_cat_name,service_name,city_name,message,or_date,o_status,or_address);
                    leadsList.add(leads1);


                        if(!jsonObject.getString("customer_id").equals("null")) {
                            JSONObject jsonObject1 = jsonObject.getJSONObject("customer_id");
                            Log.d("JSON:", "" + jsonObject1);

                            String js=jsonObject1.getString("cname");
                            String jm=jsonObject1.getString("mobile");
                            leads1.setMobile(jm);

                           leads1.setCname(js);



                            shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor=shp.edit();




                        }


                        if(!jsonObject.getString("provider_id").equals("null")) {
                            JSONObject jsonObject2 = jsonObject.getJSONObject("provider_id");
                            Log.d("JSON:", "" + jsonObject2);

                            String pname = jsonObject2.getString("pname");

                           leads1.setPame(pname);

                        }

                        if(!jsonObject.getString("c_atname").equals("null")) {
                            JSONObject jsonObject2 = jsonObject.getJSONObject("c_atname");
                            Log.d("JSON:", "" + jsonObject2);

                            String cat_name = jsonObject2.getString("categoryname");

                              leads1.setCat_name(cat_name);

                        }

                        if(!jsonObject.getString("sub_cat_name").equals("null")) {
                            JSONObject jsonObject2 = jsonObject.getJSONObject("sub_cat_name");
                            Log.d("JSON:", "" + jsonObject2);

                            String subtitle = jsonObject2.getString("subtitle");

                            leads1.setSubtitle(subtitle);

                        }

                        if(!jsonObject.getString("child_cat_name").equals("null")) {
                            JSONObject jsonObject2 = jsonObject.getJSONObject("child_cat_name");
                            Log.d("JSON:", "" + jsonObject2);

                            String childtitle = jsonObject2.getString("childtitle");

                            leads1.setChildtitle(childtitle);

                        }




                    }
                    adapter.notifyDataSetChanged();


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            protected Map<String,String> getParams() {
                Map<String, String> map = new HashMap<>();
//               Log.d("cakeon",""+cid);
                map.put("status", "Pending");
                map.put("cid", category_id);
                return map;
            }

        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);



    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void showNotification()
    {
        Uri sound = Uri.parse("android.resource://" + getApplicationContext().getPackageName() + "/" + R.raw.sound);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(NewLead.this, "default_notification_channel_id" )
                .setSmallIcon(R.drawable. ic_launcher_foreground )
                .setContentTitle( "Test" )
                .setSound(sound)
                .setContentText( "Hello! This is my first pushnotification" ) ;
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context. NOTIFICATION_SERVICE );
        if (android.os.Build.VERSION. SDK_INT >= android.os.Build.VERSION_CODES. O ) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes. CONTENT_TYPE_SONIFICATION )
                    .setUsage(AudioAttributes. USAGE_ALARM )
                    .build() ;
            int importance = NotificationManager. IMPORTANCE_HIGH ;
            NotificationChannel notificationChannel = new NotificationChannel( "NOTIFICATION_CHANNEL_ID" , "NOTIFICATION_CHANNEL_NAME" , importance) ;
            notificationChannel.enableLights( true ) ;
            notificationChannel.setLightColor(Color. RED ) ;
            notificationChannel.enableVibration( true ) ;
            notificationChannel.setVibrationPattern( new long []{ 100 , 200 , 300 , 400 , 500 , 400 , 300 , 200 , 400 }) ;
            notificationChannel.setSound(sound , audioAttributes) ;
            mBuilder.setChannelId( "NOTIFICATION_CHANNEL_ID" ) ;
            assert mNotificationManager != null;
            mNotificationManager.createNotificationChannel(notificationChannel) ;
        }
        assert mNotificationManager != null;
        mNotificationManager.notify(( int ) System. currentTimeMillis () ,
                mBuilder.build()) ;
    }



    public void onBackPressed() {
        Intent gotoBack = new Intent(NewLead.this, Home.class);
        //gotoBack.putExtra(USER_GLOBAL_SENDER, username_global); <-- Use this if you want to carry some data to the other activity.
        startActivity(gotoBack);
    }



}