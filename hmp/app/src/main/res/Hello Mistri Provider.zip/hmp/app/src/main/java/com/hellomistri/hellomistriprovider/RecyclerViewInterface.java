package com.hellomistri.hellomistriprovider;

public interface RecyclerViewInterface {

     void onItemClick(int position);

}
