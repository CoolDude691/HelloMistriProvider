package com.hellomistri.hellomistriprovider.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.load.model.Model;
import com.hellomistri.hellomistriprovider.Model.Leads;
import com.hellomistri.hellomistriprovider.Model.ProLeads;
import com.hellomistri.hellomistriprovider.R;

public class Completedet extends AppCompatActivity {
    TextView location,call,txttitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comp_det);
        location= findViewById(R.id.txt_location);
        call=findViewById(R.id.txt_call);

        txttitle=findViewById(R.id.txt_title);



        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number= String.valueOf(123);

                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:"+number));//change the number
                startActivity(callIntent);



            }
        });

        /*Leads object= (Leads) getIntent().getSerializableExtra("leaddet");

        txttitle.setText(""+object.getName());*/













    }
}