package com.hellomistri.hellomistriprovider.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.hellomistri.hellomistriprovider.Model.Leads;
import com.hellomistri.hellomistriprovider.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class Edit_User extends AppCompatActivity {

    ImageView imgProfile;
    TextInputEditText name,phone,email,address,pincode,aa,servicecat,km;
     Button update;
     TextView ProviderId;
    String pcity, pcategory;
     ImageView front,back;

    SharedPreferences shp;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        name= findViewById(R.id.userName);
        phone= findViewById(R.id.userPhone);
        email= findViewById(R.id.userEmail);
        address= findViewById(R.id.userAddress);
        pincode= findViewById(R.id.userPincode);
        servicecat= findViewById(R.id.userSubCtegory);
        front = findViewById(R.id.img_aaback1);
        back=findViewById(R.id.img_aaback);
        ProviderId = findViewById(R.id.ProviderId);
        imgProfile = findViewById(R.id.provider_profile_image);
        update=findViewById(R.id.btn_update);
        aa= findViewById(R.id.aadhar);
        km= findViewById(R.id.userDis);
        shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();

        String aadf = shp.getString("afront","");
        String aadb = shp.getString("aback","");




        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CallApi();
                Intent intent = new Intent(Edit_User.this,EditPropUpdate.class);
                startActivity(intent);
            }
        });

        String name1 = shp.getString("name", "");
        String email1 = shp.getString("email", "");
        String mobileq = shp.getString("mobile", "");
        String address1 = shp.getString("address", "");
        String pincq = shp.getString("pincode", "");
        String scq = shp.getString("subcategory", "");
        String aad = shp.getString("adharno", "");
        String liko = shp.getString("distance", "");



       // Toast.makeText(this, ""+liko, Toast.LENGTH_SHORT).show();
        getProDetails();

//        name.setText(name1);
//        email.setText(email1);
//        phone.setText(mobileq);
//        address.setText(address1);
//        pincode.setText(pincq);
//          servicecat.setText(scq);
//          aa.setText(aad);
//          km.setText(liko);

        String url="https://hellomistri.com/";
        Glide.with(front).load(url+aadf).into(front);
        Glide.with(back).load(url+aadb).into(back);



        //imgProfile=findViewById(R.id.img_profile);

     /*   imgProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,""),112);
            }
        });*/
    }


    private void selectImage() {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(Edit_User.this);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Intent intent=new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent,"image"),111);
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);





    }


//    private void CallApi() {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("Loading");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
//
//
//        shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor=shp.edit();
//
///*
//     String cid= String.valueOf(1);
//*/
//
//
//        String proid = shp.getString("uid", "");
//        String category_id = shp.getString("category_id", "");
//
//        String name1 = name.getText().toString();
//        String phone1 =phone .getText().toString();
//        String email1 = email.getText().toString();
//        String address1 = address.getText().toString();
//        String pincode1 = pincode.getText().toString();
//        String Service1 = servicecat.getText().toString();
//        String km1  = km.getText().toString();
//        String aadhar = aa.getText().toString();
//
//
//        //Toast.makeText(this, ""+category_id, Toast.LENGTH_SHORT).show();
//
//        String url="https://hellomistri.in/index/db/api/get_profile.php";
//        RequestQueue requestQueue= Volley.newRequestQueue(this);
//        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                progressDialog.dismiss();
//
//                   Toast.makeText(Edit_User.this, ""+response, Toast.LENGTH_SHORT).show();
//
//
////                Log.d("leads",response);
////                Toast.makeText(Edit_User.this, ""+response, Toast.LENGTH_SHORT).show();
//
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                error.printStackTrace();
//
//            }
//        }){
//            protected Map<String,String> getParams() {
//                Map<String, String> map = new HashMap<>();
////               Log.d("cakeon",""+cid);
//                map.put("id",proid );
////                map.put("name", name1);
////                map.put("email", email1);
////                map.put("phone", phone1);
////                map.put("pincode", pincode1);
////                map.put("id", proid);
////                map.put("aadharfront", "");
////                map.put("aadharback", "");
//                return map;
//            }
//
//        };
//        stringRequest.setShouldCache(false);
//        requestQueue.add(stringRequest);
//
//
//
//    }


    private void getProDetails() {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();
        SharedPreferences shp = Edit_User.this.getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();
        String proid = shp.getString("uid", "");

        String url="https://hellomistri.in/index/db/api/get_profile.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();



                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i=0;i<jsonArray.length();i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String pid = jsonObject.getString("id");
                        String pname = jsonObject.getString("name");
                        String pemail = jsonObject.getString("email");
                        String pmobile = jsonObject.getString("mobile");
                        pcategory = jsonObject.getString("category_id");
                        String paddress = jsonObject.getString("address");
                        pcity = jsonObject.getString("city");
                        String pccode = jsonObject.getString("ccode");
                        String padharno = jsonObject.getString("adharno");
                        String paback = jsonObject.getString("aback");
                        String pafront = jsonObject.getString("afront");
                        String paprove = jsonObject.getString("aprove");
                        String pimg = jsonObject.getString("pimg");
                        String pdis = jsonObject.getString("distance");

                        if (paprove.equals("0")){

                            update.setVisibility(View.VISIBLE);

                        }else
                        {

                            update.setVisibility(View.GONE);
                        }
                        getProCity();
                        getProCategroy();
                        ProviderId.setText("HMP"+pid);
                        name.setText(pname);
                        email.setText(pemail);
                        phone.setText(pmobile);
                        address.setText(paddress);
                        aa.setText(padharno);
                        km.setText(pdis);
                        String url1="https://hellomistri.in/index/db/api/uploads/";
                        Glide.with(front).load(url1+pafront).into(front);
                        Glide.with(back).load(url1+paback).into(back);


                        if (!pimg.equals(null))
                        {
                            String url12="https://hellomistri.in/index/db/api/uploads/";
                            Glide.with(imgProfile).load(url12+pimg).into(imgProfile);
                        }
                        else {
                            Toast.makeText(Edit_User.this, "Profile not Available", Toast.LENGTH_SHORT).show();
                        }


                      //  Toast.makeText(Edit_User.this, "" + pimg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
//                    throw new RuntimeException(e);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            protected Map<String,String> getParams() {
                Map<String, String> map = new HashMap<>();
//               Log.d("cakeon",""+cid);
                map.put("id",proid );

                return map;
            }

        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);

    }



    private void getProCity() {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();
        SharedPreferences shp = Edit_User.this.getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();
        String proid = shp.getString("uid", "");

        String url="https://hellomistri.in/index/db/api/get_city.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();



                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i=0;i<jsonArray.length();i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String pcid = jsonObject.getString("id");
                        String pcname = jsonObject.getString("cname");

                        pincode.setText(pcname);
                       // Toast.makeText(Edit_User.this, ""+pcname, Toast.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
              //      throw new RuntimeException(e);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            protected Map<String,String> getParams() {
                Map<String, String> map = new HashMap<>();
//               Log.d("cakeon",""+cid);
                map.put("id",pcity );

                return map;
            }

        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);

    }


    private void getProCategroy() {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();
        SharedPreferences shp = Edit_User.this.getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();
        String proid = shp.getString("uid", "");

        String url="https://hellomistri.in/index/db/api/get_cat.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();



                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i=0;i<jsonArray.length();i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String pcid = jsonObject.getString("id");
                        String cat_name = jsonObject.getString("cat_name");
                        servicecat.setText(cat_name);
                       // Toast.makeText(Edit_User.this, ""+pcname, Toast.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                 //   throw new RuntimeException(e);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            protected Map<String,String> getParams() {
                Map<String, String> map = new HashMap<>();
//               Log.d("cakeon",""+cid);
                map.put("id",pcategory );

                return map;
            }

        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);

    }

}