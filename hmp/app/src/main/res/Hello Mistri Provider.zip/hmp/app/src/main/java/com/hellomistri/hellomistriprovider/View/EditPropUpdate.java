package com.hellomistri.hellomistriprovider.View;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hellomistri.hellomistriprovider.Fragments.User_Profile;
import com.hellomistri.hellomistriprovider.Model.User;
import com.hellomistri.hellomistriprovider.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class EditPropUpdate extends AppCompatActivity {
    CircleImageView imageView;
    Toolbar toolbar;
    ImageView uploadA,uploadP,UploadProfile;

    Spinner e1,e3;

    SharedPreferences preferences;


    ArrayList<String> cityList= new ArrayList<>();
    ArrayList<String> catlist= new ArrayList<>();

    ArrayAdapter<String> cityAdapter,catAdapter;
    EditText editText,editText1,editText3,e2,e4,e5,e6,e7,signature;
    Button submit;
    ImageView backButtonUyP , skip;
    Bitmap aadharBitmap,abackBitmap,proBitmap;
    AlertDialog.Builder builder;
    RequestQueue requestQueue;
    String profilePhotoPath,aadharPhotoPath,panPhotoPath;
    SharedPreferences shp;
    //  Modeld customerData;
    boolean isImageAdded = false;
    String action="";
    //  Model device;


    private  int request_code= 100;



/*
    private void initToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_baseline_arrow_back_24);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Add customer");
        toolbar.setTitle("Add customer");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
*/



    @SuppressLint({"WrongViewCast", "SetTextI18n", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_prop_update);
        getSupportActionBar().hide();
        requestQueue = Volley.newRequestQueue(this);
        uploadA= findViewById(R.id.imgv);
        uploadP = findViewById(R.id.imgv1);
UploadProfile = findViewById(R.id.imgv2);
        editText = findViewById(R.id.edit6);
        editText1=findViewById(R.id.edit7);
        editText3=findViewById(R.id.edit8);
        submit=findViewById(R.id.btnsub);
        e1=findViewById(R.id.spinner_city);
        e2=findViewById(R.id.edit2);
        e3=findViewById(R.id.edit3);
        e4=findViewById(R.id.edit4);
        e5=findViewById(R.id.edit5);

        skip = findViewById(R.id.backBtnSkip);


        shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();

        String name1 = shp.getString("name", "");
        String email1 = shp.getString("email", "");
        String mobileq = shp.getString("mobile", "");
        String address1 = shp.getString("address", "");
        String pincq = shp.getString("pincode", "");
        String scq = shp.getString("subcategory", "");
        String aad = shp.getString("adharno", "");
        String liko = shp.getString("distance", "");
        String city = shp.getString("city", "");

        e2.setText(name1);
        e4.setText(liko);
        e5.setText(aad);
        //e1.setSelection(Integer.parseInt(city));



        e1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences preferences = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                Intent in = new Intent(EditPropUpdate.this,RefferalActivity.class);
                startActivity(in);
                editor.remove("isLogin");
                editor.commit();
                finish();
            }
        });





        backButtonUyP = findViewById(R.id.backBtnuyp);
        backButtonUyP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        BookService();
        updateLocation();
         preferences = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor1 = preferences.edit();
        editor.putBoolean("isLogin", true);
        editor.commit();

        //  initToolbar();
//        shp=getSharedPreferences("MySharedPref",MODE_PRIVATE);
//        SharedPreferences.Editor editor= shp.edit();

        Intent intent=getIntent();
        action= intent.getStringExtra("actionOfCustomer");
      /*  if(action.equals("edit")){
         //   customerData=(Modeld) intent.getSerializableExtra("cust_objs");
            Log.d("customer_edit",customerData.getAadharcard());
            e1.setText(""+customerData.getName());
            e2.setText(""+customerData.getPhone());
            e3.setText(""+customerData.getEmail());
            e4.setText(""+customerData.getAddress());
            e5.setText(""+customerData.getPincode());
            e6.setText(""+customerData.getAadharcard());
            e7.setText(""+customerData.getPancard());
            Glide.with(this).load(Uri.parse("https://krishnadeep.com/key_override/uploads/"+customerData.getProfileimage())).into(imageView);
            signature.setText(""+customerData.getSignature());
        }else if(action.equals("insert"))
        {

            device=(Model) intent.getSerializableExtra("device_objs");
            Log.d("customer_edit",device.getId());
        }*/


        UploadProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,""),11);

            }
        });

        /*back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(add_customer.this, customer.class);
                startActivity(intent);
            }
        });*/

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                   if (CheckAllFields()){
                       customer_det();
                   }else
                   {
                       Toast.makeText(EditPropUpdate.this, "Required", Toast.LENGTH_SHORT).show();
                   }

                    // Allbtn();
                   /* if(action.equals("edit")){
                        //   updateCustomer();
                    }else if(action.equals("insert")){
                        //  customer_det();
                    }*/




            }
        });
        uploadA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,""),112);
            }
        });

        uploadP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,""),113);
            }
        });



/*
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            */
/*    Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(Intent.createChooser(intent,""),111);*//*

//                imageView.setImageDrawable(null);
                int cameraPermissionCount=shp.getInt("camera_permissions",0);
                if(shp.getInt("camera_permissions",0)>=2){
                    Log.d("camera_permission","called intent");
                    Toast.makeText(NewRegPage.this, "Allow camera permissions first", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent();
                    i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    i.addCategory(Intent.CATEGORY_DEFAULT);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                    i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                    startActivity(i);
                }else if(shp.getInt("camera_permissions",0)<2 && ContextCompat.checkSelfPermission(NewRegPage.this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(NewRegPage.this,new String[]{Manifest.permission.CAMERA},107);
                    editor.putInt("camera_permissions",cameraPermissionCount+1);
                    editor.apply();
                }else{
                    selectImage();
                }



            }
        });
*/

    }


    @SuppressLint("Range")
    public String getRealPathFromURI(Uri uri) {
        String res = null;
        if (uri.getScheme().equals("content")){
            Cursor cursor = getApplicationContext().getContentResolver().query(uri,null,null,null,null);

            try {
                if (cursor != null && cursor.moveToFirst())
                {
                    res = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));

                }
            }finally {
                cursor.close();
            }
            if (res == null)
            {
                res = uri.getPath();
                int cutt = res.lastIndexOf('/');
                if (cutt != -1)
                {
                    res = res.substring(cutt +1);
                }

            }
        }
        return res;
    }

    public byte[] getFileDataFromDrawable(Context context, Bitmap bitmap) {
//        Bitmap bitmap = photo;
//        bitmap=rotateImage(bitmap,90);
//        bitmap= getResizedBitmap(bitmap,1920);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 40, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }

        return Bitmap.createScaledBitmap(image, width, height, true);
    }


    private final int requestcode = 123;
    private final int requestcode1 = 125;




    private boolean CheckAllFields() {



     /*   if (profileImageBitmap == null && !action.equals("edit")){
            Toast.makeText(EditPropUpdate.this, "Please provide profile picture", Toast.LENGTH_SHORT).show();
            return false;
        }*/

        if (e1.getSelectedItemPosition() > 0) {
// get selected item value
            String itemvalue = String.valueOf(e1.getSelectedItem());
        } else {
// set error message on spinner
            TextView errorTextview = (TextView) e1.getSelectedView();
            errorTextview.setError("Your Error Message here");
        }

        if (e2.length() == 0) {
            e2.setError("Phone is required");
            return false;
        }

        if (e3.getSelectedItemPosition() > 0) {
// get selected item value
            String itemvalue = String.valueOf(e3.getSelectedItem());
        } else {
// set error message on spinner
            TextView errorTextview1 = (TextView) e3.getSelectedView();
            errorTextview1.setError("Your Error Message here");
        }

        if (e4.length() == 0) {
            e4.setError("Address is required");
            return false;
        } else if (e5.length() ==0){

            e5.setError("Pincode is required");
            return false;

        }
    else if(editText.length() ==0)
        {
            editText.setError("Aadhar front Required");
            return false;
        }
    else if(editText1.length() == 0)
        {
            editText1.setError("Aadhar Back Required");
            return false;
        }

   else if (editText3.length() == 0)
        {
            editText1.setError("Aadhar Back Required");
            return false;
        }

 /* if (aadharBitmap == null && !action.equals("edit")){
            Toast.makeText(EditPropUpdate.this, "Please provide signature", Toast.LENGTH_SHORT).show();
            return false;
        }*/


        // after all validation return true.
        return true;
    }




    private void askpermission() {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent,requestcode);
    }

    private void askpermissionP() {
        Intent intent1 = new Intent(Intent.ACTION_GET_CONTENT);
        intent1.setType("*/*");
        startActivityForResult(intent1,requestcode1);
    }
    private File createImageFile(int number) throws IOException{
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        switch (number){
            case 1:
                profilePhotoPath=image.getAbsolutePath();
                break;
            case 2:
                aadharPhotoPath=image.getAbsolutePath();
                break;
            case 3:
                panPhotoPath=image.getAbsolutePath();
                break;
        }
        return image;
    }


    /*  @Override
      public boolean onCreateOptionsMenu(Menu menu) {
          // Inflate the menu; this adds options to the action bar if it is present.
          getMenuInflater().inflate(R.menu.main, menu);
          return true;
      }*/
    private void selectImage() {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Intent intent=new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent,"image"),111);
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }



    private void updateLocation() {




        String url="https://hellomistri.in/index/db/city.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);


        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //    Toast.makeText(ServiceBooking.this, ""+response, Toast.LENGTH_SHORT).show();

                try {
                    JSONArray jsonArray= new JSONArray(response);

                    for (int i=0;i<jsonArray.length();i++) {

                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        SharedPreferences shp = getApplication().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor=shp.edit();
                        String id = jsonObject.getString("id");
                        String cname = jsonObject.getString("cname");

                        // Toast.makeText(NewRegPage.this, "City"+id, Toast.LENGTH_SHORT).show();

                        editor.putString("cityId",jsonObject.getString("id"));
                        editor.commit();

                        cityList.add(cname);
//                        cityList.add(id);
                        cityAdapter=new ArrayAdapter<String>(EditPropUpdate.this, android.R.layout.simple_list_item_1,cityList);
                        cityAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
                        e1.setAdapter(cityAdapter);



                    }
                } catch (JSONException e) {


                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        requestQueue.add(request);
        requestQueue.getCache().clear();

    }



    private void BookService() {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();


        String url="https://hellomistri.in/Api/getCategory";
        RequestQueue requestQueue= Volley.newRequestQueue(this);


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();

                //  Toast.makeText(Dashboard.this, ""+response, Toast.LENGTH_SHORT).show();


                try {
                    JSONArray jsonArray = new JSONArray(response);

                    for (int i=0;i<jsonArray.length();i++)
                    {
                        SharedPreferences shp = getApplication().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor=shp.edit();
                        JSONObject jsonObject= jsonArray.getJSONObject(i);

                        String id = jsonObject.getString("id");
                        String cat_name = jsonObject.getString("cat_name");
                        editor.putString("uid",jsonObject.getString("id"));

                        //Toast.makeText(NewRegPage.this, "cat"+id, Toast.LENGTH_SHORT).show();


                        editor.commit();


                        catlist.add(cat_name);
                        catAdapter=new ArrayAdapter<String>(EditPropUpdate.this, android.R.layout.simple_list_item_1,catlist);
                        catAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
                        e3.setAdapter(catAdapter);


                        editor.putString("id",jsonObject.getString("id"));
                        editor.commit();

                       /* e1.setOnItemSelectedListener(new ArrayAdapter().OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                selectedBatch = mySpinner.getItemAtPosition(position).toString();
                                batchid = jsonObject.optString("Batch_Id");


                            }*/




                        //  Toast.makeText(Dashboard.this, ""+cat_name, Toast.LENGTH_SHORT).show();


                        //     Toast.makeText(Dashboard.this, ""+jsonObject, Toast.LENGTH_SHORT).show();

                    }




                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {



            }

        });


        requestQueue.add(stringRequest);
        requestQueue.getCache().

                clear();




    }



/*
    private void Allbtn() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();




        String url="https://hellomistri.in/index/db/api/update_reg.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);


        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();

             //   Toast.makeText(NewRegPage.this, ""+response, Toast.LENGTH_SHORT).show();
                Intent i = new Intent(NewRegPage.this,RefferalActivity.class);
                startActivity(i);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {


            }

        }){
            protected Map<String,String> getParams() {
                Map<String, String> map = new HashMap<>();
//                Log.d("cakeon",""+cid +" " +uid);

                return map;
            }
        };;


        requestQueue.add(stringRequest);
        requestQueue.getCache().

                clear();




    }
*/


    private void customer_det() {

        SharedPreferences shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String mobile = shp.getString("mobile","");
        String city = e1.getSelectedItem().toString();
        String add = e2.getText().toString();
        String sc = e3.getSelectedItem().toString();
        String dis = e4.getText().toString();
        String ahar = e5.getText().toString();
        String ua = editText.getText().toString();
        String ub = editText1.getText().toString();
        String pp = editText3.getText().toString();


        shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();
        String uid1 = shp.getString("uid", "");


        String url="https://hellomistri.in/index/db/api/image_upload.php";;
        Log.d("registerdriver","api_called");
        ProgressDialog pd = new ProgressDialog(EditPropUpdate.this);
        pd.setMessage("Loading....");
        pd.show();
        RequestQueue requestQueue= Volley.newRequestQueue(this);


        VolleyMultipartRequest volleyMultipartRequest=new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                pd.dismiss();

                String result=new String(response.data);
                Log.d("registerdriver",result);


                SharedPreferences preferences = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                Intent in = new Intent(EditPropUpdate.this,SignIn.class);
                startActivity(in);
                editor.remove("isLogin");
                editor.commit();
                finish();

                Toast.makeText(EditPropUpdate.this, "Profile Updated SuccessFully", Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        }){
            protected Map<String,String> getParams(){
                Map<String,String> map=new HashMap<>();

                map.put("mobile",mobile);
                if (e1 ==  null) {
                    map.put("city", city);
                }

                map.put("address",add);
                if (e3==null) {
                    map.put("cid", sc);
                }
                map.put("distance",dis);
                map.put("aadharno",ahar);

                if (aadharBitmap == null){
                map.put("afront",ua);
                }
                if (abackBitmap == null) {
                    map.put("aback", ub);
                }
                if (proBitmap ==null) {
                    map.put("pimg", pp);
                }

                return map;
            }
            protected Map<String,DataPart> getByteData(){
                Map<String,DataPart> map=new HashMap<>();
                long current  = new Date().getTime();
                if (aadharBitmap != null)
                {
                    map.put("afront",new DataPart("profile"+current+".jpg",getFileDataFromDrawable(EditPropUpdate.this,aadharBitmap),"image/jpeg"));
                }
                if (abackBitmap != null)
                {
                    map.put("aback",new DataPart("profile"+current+".jpg",getFileDataFromDrawable(EditPropUpdate.this,abackBitmap),"image/jpeg"));
                }

                if (proBitmap != null)
                {
                    map.put("pimg",new DataPart("profile"+current+".jpg",getFileDataFromDrawable(EditPropUpdate.this,proBitmap),"image/jpeg"));
                }



                return map;
            }
        };
        volleyMultipartRequest.setShouldCache(false);
        requestQueue.add(volleyMultipartRequest);



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);



     /*   if (requestCode==0  && data!=null)
        {


            Bundle b = data.getExtras();
            profileImageBitmap = (Bitmap) b.get("data");

            imageView.setImageBitmap(profileImageBitmap);
        }*/


      /*  if (requestCode==111   && data!=null)
        {
            Uri imageUri = data.getData();

            try {
                profileImageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                imageView.setImageBitmap(profileImageBitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }*/
        if (requestCode == 112 && data!=null)
        {
            Uri imageUri = data.getData();
            editText.setText(getRealPathFromURI(imageUri));


            try {
                aadharBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (requestCode == 113 && data!=null)
        {
            Uri imageUri = data.getData();
            editText1.setText(getRealPathFromURI(imageUri));
            isImageAdded =true;
            try {
                abackBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (requestCode == 11 && data!=null)
        {
            Uri imageUri = data.getData();
            editText3.setText(getRealPathFromURI(imageUri));

            isImageAdded =true;
            try {
                proBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }







}
