package com.hellomistri.hellomistriprovider.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;
import com.hellomistri.hellomistriprovider.Model.User;
import com.hellomistri.hellomistriprovider.View.NewLead;
import com.hellomistri.hellomistriprovider.View.ProcessingLead;
import com.hellomistri.hellomistriprovider.R;
import com.hellomistri.hellomistriprovider.View.CancledLead;
import com.hellomistri.hellomistriprovider.View.CompletedLead;
import com.hellomistri.hellomistriprovider.View.Wallet;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeFragment extends Fragment {
    
    CardView newLead,processing,completed,cancle,userProfile,wallet;
    TextView UserName,emailName;

    SharedPreferences shp;
    String aprove;
    List<User> list = new ArrayList<>();
    String apr , aproved;

    String ii = "1";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_home, container, false);
        newLead = view.findViewById(R.id.newLeadCard);
        processing = view.findViewById(R.id.processingLeadCard);
        completed = view.findViewById(R.id.completedLeadCard);
        cancle = view.findViewById(R.id.cancleLeadCard);
      //  userProfile = view.findViewById(R.id.profileLeadCard);
        wallet = view.findViewById(R.id.walletLeadCard);
        UserName=view.findViewById(R.id.userN);
        emailName=view.findViewById(R.id.emailId);

       /* aprove =(User) getActivity().getIntent().getSerializableExtra("seri");

       aprove.getAprove();

        Toast.makeText(getContext(), ""+aprove, Toast.LENGTH_SHORT).show();*/

        shp = getContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();



        String name = shp.getString("name", "");
        String email = shp.getString("email", "");

        UserName.setText(name);
        emailName.setText(email);


        aprovalProfile();

//       String ii= getArguments().getString("name");
     /*String oo=  getArguments().getString("email");
    */


        newLead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               if (aproved.equals(ii)){

                  Intent newlead = new Intent(getContext(), NewLead.class);
                  startActivity(newlead);

               }
               else
               {
                   Toast.makeText(getContext(), "Your Acount Is not Aproved", Toast.LENGTH_SHORT).show();
               }


            }
        });
        processing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (aproved==ii){

                    Intent processing = new Intent(getContext(), ProcessingLead.class);
                    startActivity(processing);

                }
                else
                {
                    Toast.makeText(getContext(), "Your Acount Is not Aproved", Toast.LENGTH_SHORT).show();
                }
            }
        });
        completed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (aproved.equals(ii)){

                    Intent complete = new Intent(getContext(), CompletedLead.class);
                    startActivity(complete);

                }
                else
                {
                    Toast.makeText(getContext(), "Your Acount Is not Aproved", Toast.LENGTH_SHORT).show();
                }
            }
        });
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (aproved.equals(ii)){

                    Intent cancled = new Intent(getContext(), CancledLead.class);
                    startActivity(cancled);

                }
                else
                {
                    Toast.makeText(getContext(), "Your Acount Is not Aproved", Toast.LENGTH_SHORT).show();
                }
            }
        });

        wallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent wallets = new Intent(getContext(), Wallet.class);
                startActivity(wallets);
            }
        });

        return view;
    }

    private void aprovalProfile() {

        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();
        SharedPreferences shp = getActivity().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=shp.edit();
        String proid = shp.getString("uid", "");

        String url="https://hellomistri.in/index/db/api/aproval.php";
        RequestQueue requestQueue= Volley.newRequestQueue(getContext());
        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String aproval = jsonObject.getString("aprove");
                    aproved = aproval;
                } catch (JSONException e) {
                //    throw new RuntimeException(e);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        }){
            protected Map<String,String> getParams() {
                Map<String, String> map = new HashMap<>();
//               Log.d("cakeon",""+cid);
                map.put("pid",proid );

                return map;
            }

        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);



    }



}