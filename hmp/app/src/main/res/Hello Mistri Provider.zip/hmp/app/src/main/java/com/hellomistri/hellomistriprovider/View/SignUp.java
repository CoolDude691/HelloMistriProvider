package com.hellomistri.hellomistriprovider.View;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hellomistri.hellomistriprovider.R;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class SignUp extends AppCompatActivity {

    Button signUp,Getotp,SignIn;
    String getName,getEmail,getMobile,getOtp;
    String send_otp;
    EditText userName;
    EditText userEmail;
    EditText userMobile;
    EditText regotp;
    String inputOtp,inputUserName,inputUserEmail,inputUserNumber ;
    TextView ename,eEmail,enumber;
    LinearLayout registerotptext;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        getSupportActionBar().hide();
        SignIn = findViewById(R.id.signIn);
        signUp=findViewById(R.id.signUp);
        userName = findViewById(R.id.userName);
        userEmail = findViewById(R.id.userEmail);
        userMobile = findViewById(R.id.userMobile);
        registerotptext=findViewById(R.id.registerotptext);
        regotp=findViewById(R.id.regotp);
        Getotp=findViewById(R.id.signUp1);
        ename = findViewById(R.id.eName);
        eEmail = findViewById(R.id.eEmail);
        enumber = findViewById(R.id.eNumber);

        Getotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(TextUtils.isEmpty(userMobile.getText().toString()))
                {
                    userMobile.setError("required");

                }
                if(TextUtils.isEmpty(userEmail.getText().toString()))
                {
                    userEmail.setError("required");
                }
                if(TextUtils.isEmpty(userName.getText().toString()))
                {
                    userName.setError("required");
                }
                else {

                    getMobile = userMobile.getText().toString();
                    final Random myRandom = new Random();
                    getOtp= String.format("%04d", myRandom.nextInt(10000));
                    getOtp(getMobile,getOtp);

                    registerotptext.setVisibility(View.VISIBLE);
                    ename.setVisibility(View.GONE);
                    eEmail.setVisibility(View.GONE);
                    enumber.setVisibility(View.GONE);
                    userName.setVisibility(View.GONE);
                    userMobile.setVisibility(View.GONE);
                    userEmail.setVisibility(View.GONE);
                    Getotp.setVisibility(View.GONE);
                    signUp.setVisibility(View.VISIBLE);

                }
            }
        });
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                inputUserName = userName.getText().toString();
                inputUserEmail = userEmail.getText().toString();
                inputUserNumber = userMobile.getText().toString();
                inputOtp = regotp.getText().toString();

                if (inputOtp.equals(getOtp)) {
                    registrationOtp();
                }

            }
        });

    }


    private void registrationOtp() {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();



        String url="https://hellomistri.in/index/db/api/registration.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);

        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();


                Intent intent = new Intent(SignUp.this, NewRegPage.class);
                startActivity(intent);
                /*if (response.equals("Success")){

                SharedPreferences preferences = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("inputUserNumber", String.valueOf(inputUserNumber));
                editor.commit();
                Toast.makeText(SignUp.this, ""+response, Toast.LENGTH_SHORT).show();
              *//*  Intent intent = new Intent(SignUp.this, NewRegPage.class);
                startActivity(intent);*//*

                }
                else {

                 *//*   Toast.makeText(SignUp.this, ""+response, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignUp.this, SignIn.class);
                    startActivity(intent);*//*
                }*/

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }){

            protected Map<String,String> getParams(){

                Map<String,String> map=new HashMap<>();
                map.put("name", inputUserName);
                map.put("email", inputUserEmail);
                map.put("mobile", inputUserNumber);
                map.put("otp",inputOtp);
                return map;
            }
        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);



    }

    private void updateOtp() {


        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();

        String url="https://hellomistri.in/index/db/api/otp_verify.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();

                Log.d("responseDeviceDetails",response);

                SharedPreferences preferences = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.clear();
                editor.putString("name", String.valueOf(userName));
                editor.putString("email", String.valueOf(userEmail));
                editor.putString("mobile", String.valueOf(userMobile));
                editor.commit();

                String msg = "Success";
                if (response.equals(msg)){
                    Intent intent = new Intent(SignUp.this, NewRegPage.class);
                    startActivity(intent);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();


            }
        }){
            protected Map<String,String> getParams(){
                Map<String,String> map=new HashMap<>();
                // Log.d("cakeon",""+email +" " +password);
                map.put("mobile", String.valueOf(userMobile));
                map.put("otp",getOtp);
                return map;
            }
        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);



    }

/*
    private void registrationOtp(String getOtp , String getMobile ,String getName,String getEmail ) {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();

        String url="https://hellomistri.in/index/db/api/registration.php";
        RequestQueue requestQueue= Volley.newRequestQueue(this);

        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }){

            protected Map<String,String> getParams(){

                Map<String,String> map=new HashMap<>();
                map.put("name", getName);
                map.put("email", getEmail);
                map.put("mobile", getMobile);
                map.put("otp",getOtp);
                return map;
            }
        };
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);



    }
*/
//    private void getOtp(String getMobile, String getOtp) {
//
//        ProgressDialog progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("Loading");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
//
//        String url="https://smsinteract.in/SMSApi/send?userid=hellomistri&password=6y2xVjjA&sendMethod=quick&mobile="+ this.getMobile +"&msg=OTP to verify your Hello Mistri Account is "+ this.getOtp +" and valid till 2 minutes. Do not share this OTP to anyone for security reasons. - Team www.hellomistri.com&senderid=HMSTRI&msgType=text&duplicatecheck=true&format=text";
//        RequestQueue requestQueue= Volley.newRequestQueue(this);
//        StringRequest stringRequest=new StringRequest(Request.Method.GET, url,new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                progressDialog.dismiss();
//                Log.d("ResponseDetails",response);
//
//                registerotptext.setVisibility(View.VISIBLE);
//                Getotp.setVisibility(View.GONE);
//                signUp.setVisibility(View.VISIBLE);
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                error.printStackTrace();
//
//            }
//        });
//        stringRequest.setShouldCache(false);
//        requestQueue.add(stringRequest);
//
//
//
//    }

    private void getOtp(String getMobile, String getOtp) {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.show();

        String url="https://smsinteract.in/SMSApi/send?userid=hellomistri&password=6y2xVjjA&sendMethod=quick&mobile="+ this.getMobile +"&msg=OTP to verify your Hello Mistri Account is "+ this.getOtp +" and valid till 2 minutes. Do not share this OTP to anyone for security reasons. - Team www.hellomistri.com&senderid=HMSTRI&msgType=text&duplicatecheck=true&format=text";
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();

                Log.d("responseDeviceDetails",response);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }
        });
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);



    }

}