package com.hellomistri.hellomistriprovider.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Toast;

import com.hellomistri.hellomistriprovider.R;

public class MainActivity extends AppCompatActivity {

    String add,ct;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        SharedPreferences shp = getApplicationContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (shp.contains("isLogin")) {


                    add = shp.getString("address","");
                    ct = shp.getString("city","");
                    if (add.isEmpty() && ct.isEmpty())
                    {
                        Intent intent = new Intent(MainActivity.this, NewRegPage.class);
                        startActivity(intent);
                        finish();
                    }
                    else {
                        Intent intent = new Intent(MainActivity.this, Home.class);
                        startActivity(intent);
                        finish();
                    }


                } else {
                    Intent intent = new Intent(MainActivity.this, Login.class);
                    startActivity(intent);
                    finish();
                }

            }
        },2500);

    }
}