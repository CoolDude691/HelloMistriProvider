package com.hellomistri.hellomistriprovider.BottomSheetDialog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.hellomistri.hellomistriprovider.R;
import com.razorpay.Checkout;

import org.json.JSONObject;

public class DialogCredit extends BottomSheetDialogFragment  {

    Button submit;
    Context activity;


    @SuppressLint("RestrictedApi")
    @Override
    public void setupDialog(@NonNull Dialog dialog, int style) {
        super.setupDialog(dialog, style);



        
        View view = LayoutInflater.from(getContext()).inflate(R.layout.activity_wallet, null);
        submit= view.findViewById(R.id.Submit);


        
        
        
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Checkout.preload(getContext());


             //   Toast.makeText(getActivity(), "Hello Submit", Toast.LENGTH_SHORT).show();

                   int payAmount = 2000;


                    payAmount = payAmount * 100;
                    final String pay = String.valueOf(payAmount);

                    Checkout checkout = new Checkout();
                    checkout.setKeyID("rzp_live_ZS2nUuoGAbZ986");

                    checkout.setImage(R.drawable.image_1);


                    final Activity activity = (Activity) getContext();


                    try {
                        JSONObject options = new JSONObject();

                        options.put("name", "HelloMistri");
                        options.put("description", "Reference No. #654321");
                       // options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");
                        options.put("theme.color", "#3399cc");
                        options.put("currency", "INR");
                        options.put("amount", pay); //pass amount in currency subunits
                     //   options.put("prefill.email", "sky06801900@gmail.com");
                        options.put("prefill.contact","8077061202");
                        JSONObject retryObj = new JSONObject();
                        retryObj.put("enabled", true);
                        retryObj.put("max_count", 4);
                        options.put("retry", retryObj);

                        checkout.open(activity, options);

                    } catch(Exception e) {
                        Log.e("TAG", "Error in starting Razorpay Checkout", e);
                    }
                }

        });
        dialog.setContentView(view);

    }




}
